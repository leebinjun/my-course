my pascal code snippets and projects
