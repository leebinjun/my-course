#!/bin/bash
rm obj/*.o obj/*.a obj/*.ppu
