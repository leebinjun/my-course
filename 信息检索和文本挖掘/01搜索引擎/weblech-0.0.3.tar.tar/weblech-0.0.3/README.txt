WebLech -- recursive URL retrieval
==================================

WebLech is a fully featured web site download tool in Java, which 
supports many features required to download websites and emulate 
standard web-browser behaviour as much as possible. WebLech is 
multithreaded and comes with a GUI console.

More information from http://weblech.sourceforge.net/
