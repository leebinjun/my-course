/*
 * Created by IntelliJ IDEA.
 * User: Michael Mason
 * Date: Jun 5, 2002
 * Time: 6:43:04 PM
 * To change template for new interface use 
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package weblech.spider;

public interface Constants
{

    /** How often to check the queue status */
    int QUEUE_CHECK_INTERVAL = 500;
    /** How long to pause for threads to finish before exitting */
    int SPIDER_STOP_PAUSE = 500;
}
