Performs URL downloading based on a set of input parameters
